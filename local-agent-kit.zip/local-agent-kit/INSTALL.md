# INSTALL — step by step

This walks you through everything. You can copy‑paste each command exactly.
If a step says something is "already" done, that's fine — the scripts are safe to re‑run.

---

## Step 0 — What "WSL" and "Ubuntu" mean here

Your Windows laptop can run Linux inside it. That Linux is called **WSL**, and the specific
Linux is **Ubuntu**. You open it like any app: press the Windows key, type **Ubuntu**, press
Enter. A black text window appears — that's where you'll paste commands. To paste in that
window, **right‑click** (or press Ctrl+Shift+V).

---

## Step 1 — Windows side (2 minutes, gives Linux enough memory)

1. Unzip `local-agent-kit` somewhere easy, like your **Downloads** folder.
2. Open the `windows` folder inside it.
3. Double‑click **`Run-Windows-Setup.bat`**.
   - A blue window explains what it does. It writes one small settings file in your user
     profile. **No admin needed.**
   - When asked **"Restart WSL now?"**, type **Y** and press Enter.
4. Close the window when it says done.

> What it did: told WSL it may use most of your RAM, so the big AI model has room to run.

---

## Step 2 — Install everything inside Ubuntu (about 45 minutes)

Open **Ubuntu** (Start menu → type "Ubuntu" → Enter), then paste these blocks one at a time.

**2a. Copy the kit into Linux (faster and avoids errors):**

```bash
cd ~
cp -r /mnt/c/Users/*/Downloads/local-agent-kit ~/ 2>/dev/null
cd ~/local-agent-kit
```

> If `cd ~/local-agent-kit` says "No such file or directory", the folder wasn't in Downloads.
> Find where you unzipped it (e.g. Desktop) and change the path, for example:
> `cp -r /mnt/c/Users/*/Desktop/local-agent-kit ~/`

**2b. Make the scripts runnable (fixes Windows/Linux text differences):**

```bash
find . -name '*.sh' -exec sed -i 's/\r$//' {} +
chmod +x setup.sh scripts/*.sh bin/*.sh
```

**2c. Run the installer:**

```bash
./setup.sh
```

Now just answer the prompts. Here is what happens, in order, and roughly how long:

| Phase | What it does | Time |
|---|---|---|
| Preflight | Checks memory, GPU, disk, internet (installs nothing) | seconds |
| Base tools | Installs git, python, etc. (only what's missing) | 1–3 min |
| Ollama | Installs the local model runner | 1–2 min |
| Models | Downloads the AI models (~5 GB small, ~19 GB big) | 15–40 min |
| Agents | Installs Aider (the coding assistant) | 1–2 min |
| Workspaces | Creates your `secure`, `research`, and `bridge` folders | seconds |

> The model download is the long part. It's normal for it to sit at a percentage for a while.
> You can safely stop with **Ctrl+C** and run `./setup.sh` again later — it resumes what's left.

---

## Step 3 — Confirm it worked

```bash
./bin/doctor.sh          # a health report; look for green/ok lines
./bin/verify-airgap.sh   # should print: PASS - the secure box has NO internet access
```

If `verify-airgap` says **PASS**, your offline protection is working.

---

## Step 4 — Put your code where the Secure Assistant can see it

Copy or move the project you want to work on into the secure folder:

```bash
cp -r /mnt/c/Users/*/Documents/my-project ~/local-agent/secure/
```

(Or just create a new empty project there.) Then start coding — see **`USAGE.md`**.

---

## Optional — stronger isolation with Docker

You do **not** need this. The offline protection already works without it. If you specifically
want the extra layer (filesystem isolation as well as network), run:

```bash
./scripts/06-docker-optional.sh
```

It installs Docker *inside* WSL (still no Windows admin needed) and builds a sealed image the
offline launcher will use automatically.
