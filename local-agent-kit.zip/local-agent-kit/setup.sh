#!/usr/bin/env bash
# setup.sh - One command that sets everything up. Safe to run again any time;
# it skips whatever is already done.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/scripts/common.sh"

printf "\n${C_BOLD}Local Agent Kit - setup${C_RESET}\n"
printf "This installs a private, offline coding assistant plus a separate research one.\n"
printf "It only installs things that are missing. You can stop with Ctrl-C and re-run later.\n"

bash "$HERE/scripts/00-preflight.sh" || true
if ! ask_yes_no "Proceed with installation?" yes; then info "Stopped. Re-run ./setup.sh whenever you like."; exit 0; fi

bash "$HERE/scripts/01-install-base.sh"
bash "$HERE/scripts/02-install-ollama.sh"
bash "$HERE/scripts/03-pull-models.sh"
bash "$HERE/scripts/04-install-agents.sh"
bash "$HERE/scripts/05-setup-workspaces.sh"

step "Core setup complete!"
ok "Verify the air-gap any time with:   ./bin/verify-airgap.sh"
ok "Health check any time with:         ./bin/doctor.sh"
ok "Start the SECURE (offline) agent:   ./bin/start-offline.sh"
ok "Start the RESEARCH (online) agent:  ./bin/start-research.sh"
info "Optional stronger isolation (Docker): ./scripts/06-docker-optional.sh"
info "Next: read USAGE.md for day-to-day examples."
