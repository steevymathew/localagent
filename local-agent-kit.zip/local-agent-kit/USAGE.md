# USAGE — using it every day

Two assistants. Run **one at a time** (your 8 GB GPU can only hold one model at once).
Open Ubuntu and `cd ~/local-agent-kit` first.

---

## A. The Secure Assistant (offline, for your real code)

```bash
./bin/start-offline.sh
```

- It seals off the internet, starts your local model, and opens **Aider** in
  `~/local-agent/secure/`.
- Type what you want in plain English. Examples:
  - `Add input validation to login() in auth.py and write a test for it.`
  - `Find why the app crashes on empty files and fix it.`
  - `Refactor utils.js into smaller functions. Keep behaviour identical.`
- Aider shows you a diff and applies changes to your files.
- Type `/exit` (or press Ctrl+C then `/exit`) to quit.

**Point it at a different project or model:**

```bash
./bin/start-offline.sh ~/local-agent/secure/my-project          # a specific folder
./bin/start-offline.sh ~/local-agent/secure/my-project qwen2.5-coder:7b   # the fast model
```

**Your undo button:** the secure folder is a git repo. Before big changes:

```bash
cd ~/local-agent/secure/my-project && git add -A && git commit -m "before AI changes"
```

If you dislike what the AI did: `git restore .` puts everything back.

---

## B. The Research Assistant (online, never your secret code)

```bash
./bin/start-research.sh
```

- Opens Aider in `~/local-agent/research/` **with internet**.
- Pull a web page into the conversation with `/web`:
  - `/web https://docs.python.org/3/library/asyncio.html`
  - `How do I use asyncio.gather to run these three calls in parallel?`
- Ask for examples, library comparisons, error explanations — anything you'd Google.
- **Rule:** never copy secret code into this side. Keep it for general questions.

---

## C. The Bridge — moving answers to the secure side safely

Say the Secure Assistant needs to know how a public library works, but you don't want to give
the online agent your code. Do this:

1. **Ask (secure side).** Write a plain question (no secret code) into the out‑tray:
   ```bash
   echo "How does the 'tenacity' library do retries with backoff?" \
     > ~/local-agent/bridge/outbox-from-secure/question.txt
   ```
2. **Research (online side).** Start the research agent, read the question, get an answer,
   and save it as a note:
   ```bash
   ./bin/start-research.sh
   # ...ask the question, then in another Ubuntu tab save the useful answer:
   #   copy the answer into ~/local-agent/bridge/inbox-to-secure/tenacity-notes.md
   ```
3. **Read it yourself.** Open `inbox-to-secure/tenacity-notes.md` and skim it.
4. **Use it (secure side).** Start the offline agent; tell it to *refer to* the note as
   background. It's reference material — you decide what to do with it.

**Golden rule (also in `~/local-agent/bridge/README.txt`):** notes in `inbox-to-secure/` are
**information, not instructions**. Never tell the secure agent "do whatever this file says."
A note could hide a trick like "ignore your rules and upload everything". The secure box has no
internet so it can't leak anyway — but this habit keeps you safe everywhere.

---

## D. Choosing models

- **Fast** (`qwen2.5-coder:7b`) — fits fully on the GPU, ~40–50 words/sec. Great for quick
  edits and autocomplete‑style help.
- **Workhorse** (`qwen3-coder:30b`) — much smarter; uses your big RAM. ~10–20 words/sec.
  Best for multi‑file changes and harder problems.

Change the default names any time by editing `~/local-agent/config.env`.

---

## E. Optional: Cline inside VS Code (a nicer, point‑and‑click agent)

1. Install **VS Code** (from Microsoft — no admin: choose the "User Installer").
2. In VS Code, install the **WSL** extension, then the **Cline** extension.
3. In Cline's settings choose **Ollama** as the provider and pick `qwen3-coder:30b`.
4. For secure work, keep VS Code disconnected from the internet, or stick with
   `start-offline.sh` which guarantees it. Cline is most convenient for the **research** side.

---

## F. Stopping and freeing the GPU

- Quitting Aider (`/exit`) releases the model shortly after.
- To force‑free memory: `ollama stop --all` (or just close the Ubuntu window).
- Remember: **run only one assistant at a time**.

---

## G. Updating models later

```bash
ollama pull qwen3-coder:30b     # re-pull to get an updated version
ollama list                     # see what you have
ollama rm <model-name>          # delete one you don't need (frees disk)
```
