# Set-WSLConfig.ps1
# Gives WSL (Linux) enough of your RAM to run the big local model.
# NO admin rights needed - it only writes a file in your own user profile.
# Safe to run again: it backs up any existing file and updates just the memory/swap lines.

$ErrorActionPreference = 'Stop'
Write-Host ""
Write-Host "Local Agent Kit - WSL memory configuration" -ForegroundColor Cyan
Write-Host "-------------------------------------------"

# 1) Work out a sensible memory amount: total RAM minus a cushion for Windows.
$totalGB = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)
$recMem  = [math]::Max(8, $totalGB - 16)   # leave ~16 GB for Windows itself
$mem     = "${recMem}GB"
$swap    = "8GB"
Write-Host ("Detected total RAM : {0} GB" -f $totalGB)
Write-Host ("Will give WSL      : {0}  (swap {1})" -f $mem, $swap)

# 2) Locate .wslconfig in your user profile.
$path = Join-Path $env:USERPROFILE ".wslconfig"

# 3) Back up any existing file.
$lines = @()
if (Test-Path $path) {
    $stamp  = Get-Date -Format "yyyyMMdd-HHmmss"
    $backup = "$path.$stamp.bak"
    Copy-Item $path $backup -Force
    Write-Host ("Backed up existing .wslconfig to: {0}" -f $backup) -ForegroundColor Yellow
    $lines = Get-Content $path
}

# 4) Remove old memory/swap lines we manage, keep everything else.
$lines = $lines | Where-Object { $_ -notmatch '^\s*(memory|swap)\s*=' }

# 5) Make sure a [wsl2] section exists.
if (-not ($lines | Where-Object { $_ -match '^\s*\[wsl2\]\s*$' })) {
    $lines += '[wsl2]'
}

# 6) Insert our two lines right after the [wsl2] header.
$out = New-Object System.Collections.Generic.List[string]
$inserted = $false
foreach ($l in $lines) {
    $out.Add($l)
    if (-not $inserted -and ($l -match '^\s*\[wsl2\]\s*$')) {
        $out.Add("memory=$mem")
        $out.Add("swap=$swap")
        $inserted = $true
    }
}

# 7) Write it back WITHOUT a BOM (WSL is picky about that).
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($path, ($out -join "`r`n") + "`r`n", $utf8NoBom)
Write-Host ("Updated: {0}" -f $path) -ForegroundColor Green

# 8) Apply the change (WSL must fully restart to pick up new memory).
Write-Host ""
Write-Host "To apply this, WSL needs to restart (closes any open Ubuntu windows)."
$ans = Read-Host "Restart WSL now? [Y/n]"
if ($ans -eq '' -or $ans -match '^(y|yes)$') {
    try { wsl --shutdown; Write-Host "WSL restarted. Reopen Ubuntu and continue in USAGE.md." -ForegroundColor Green }
    catch { Write-Host "Could not run 'wsl --shutdown' automatically. Just close all Ubuntu windows and reopen." -ForegroundColor Yellow }
} else {
    Write-Host "OK - remember to close all Ubuntu windows (or run 'wsl --shutdown') before continuing." -ForegroundColor Yellow
}
