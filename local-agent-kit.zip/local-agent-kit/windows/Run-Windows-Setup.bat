@echo off
title Local Agent Kit - Windows setup
echo ============================================================
echo   Local Agent Kit - Step 1 of 2 (Windows side)
echo   This only adjusts how much memory WSL can use.
echo   No administrator rights are required.
echo ============================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Set-WSLConfig.ps1"
echo.
echo Done with the Windows step.
echo Next: open Ubuntu (WSL) and follow INSTALL.md (Step 2).
echo.
pause
