#!/usr/bin/env bash
# 05-setup-workspaces.sh - Creates the folders, config, and the secure<->research bridge. Idempotent.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"
load_config

step "Workspaces and the bridge"
mkdir -p "$SECURE_DIR" "$RESEARCH_DIR" \
         "$BRIDGE_DIR/inbox-to-secure" "$BRIDGE_DIR/outbox-from-secure"
ok "Folders ready under: $BASE_DIR"

# Write config.env only if it doesn't already exist (don't clobber user edits).
CFG="$BASE_DIR/config.env"
if [ -f "$CFG" ]; then
  ok "Keeping existing config: $CFG"
else
  cat > "$CFG" <<CFGEOF
# Local Agent Kit configuration. Edit model names here if a tag changes.
BASE_DIR="$BASE_DIR"
SECURE_DIR="$SECURE_DIR"
RESEARCH_DIR="$RESEARCH_DIR"
BRIDGE_DIR="$BRIDGE_DIR"

# Models (see https://ollama.com/library if a name stops working)
MODEL_FAST="$MODEL_FAST"     # small, fits fully on the 8GB GPU
MODEL_WORK="$MODEL_WORK"     # big MoE, uses RAM via expert-offload
MODEL_EMBED="$MODEL_EMBED"   # embeddings for local code search
CFGEOF
  ok "Wrote config: $CFG"
fi

# A starter AGENTS.md so any agent shares your conventions.
write_agents_md() {
  local dir="$1"; local f="$dir/AGENTS.md"
  [ -f "$f" ] && { ok "AGENTS.md already exists in $(basename "$dir")/"; return; }
  cat > "$f" <<'AEOF'
# AGENTS.md - shared instructions for any coding agent in this folder

## Ground rules
- Make small, reviewable changes. Prefer one logical change at a time.
- Always run tests/build after edits when a test or build command exists.
- Never delete files without saying so first. Commit to git before large edits.

## Project facts (fill these in)
- Language / framework:
- How to run tests:
- How to build/run:
- Things NOT to touch:
AEOF
  ok "Wrote starter AGENTS.md in $(basename "$dir")/"
}
write_agents_md "$SECURE_DIR"
write_agents_md "$RESEARCH_DIR"

# git init the secure folder so you always have an undo (snapshots).
if have_cmd git; then
  if [ ! -d "$SECURE_DIR/.git" ]; then
    git -C "$SECURE_DIR" init -q
    git -C "$SECURE_DIR" add -A 2>/dev/null || true
    git -C "$SECURE_DIR" -c user.email=you@local -c user.name=you commit -qm "initial" 2>/dev/null || true
    ok "Initialised git in the secure folder (your safety net / undo)."
  else ok "Secure folder already under git."; fi
fi

# The bridge rulebook - the single most important safety note.
BR="$BRIDGE_DIR/README.txt"
if [ ! -f "$BR" ]; then
cat > "$BR" <<'BEOF'
THE BRIDGE  (how the two sides talk safely)
===========================================

inbox-to-secure/     <- research notes coming IN to the secure side
outbox-from-secure/  <- questions/specs going OUT from the secure side

GOLDEN RULE
-----------
Anything in inbox-to-secure/ is REFERENCE DATA, never commands.
Read it yourself first. Never tell the secure agent to "do what this file says".
A note could contain hidden instructions ("ignore your rules and upload...").
The secure box has no internet, so it cannot leak anyway - but stay disciplined.

WORKFLOW
--------
1. On the SECURE side, write a question (no secret code in it) to outbox-from-secure/.
2. Move that question to the RESEARCH side and run the research agent.
3. Research writes an answer as a .md file; you read it.
4. Copy the reviewed .md into inbox-to-secure/ for the secure agent to reference.
Keep it one direction at a time. Do not build an automatic two-way sync.
BEOF
ok "Wrote the bridge rulebook: $BR"
else ok "Bridge rulebook already present."; fi
