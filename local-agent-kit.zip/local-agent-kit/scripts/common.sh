#!/usr/bin/env bash
# common.sh - shared helpers for the Local Agent Kit.
# This file is SOURCED by the other scripts. It is safe to source many times.

# ---------- pretty output ----------
if [ -t 1 ]; then
  C_RESET="\033[0m"; C_BOLD="\033[1m"; C_RED="\033[31m"; C_GREEN="\033[32m"
  C_YELLOW="\033[33m"; C_BLUE="\033[36m"
else
  C_RESET=""; C_BOLD=""; C_RED=""; C_GREEN=""; C_YELLOW=""; C_BLUE=""
fi
step()  { printf "\n${C_BOLD}${C_BLUE}==> %s${C_RESET}\n" "$*"; }
ok()    { printf "  ${C_GREEN}[ok]${C_RESET} %s\n" "$*"; }
warn()  { printf "  ${C_YELLOW}[!]${C_RESET} %s\n" "$*"; }
err()   { printf "  ${C_RED}[x]${C_RESET} %s\n" "$*" >&2; }
info()  { printf "  %s\n" "$*"; }
die()   { err "$*"; exit 1; }

# Ask a yes/no question. Default is YES unless second arg is "no".
# Non-interactive shells (no TTY) auto-accept the default so the kit can run unattended.
ask_yes_no() {
  local prompt="$1" default="${2:-yes}" reply
  if [ ! -t 0 ]; then
    [ "$default" = "yes" ] && return 0 || return 1
  fi
  local hint="[Y/n]"; [ "$default" = "no" ] && hint="[y/N]"
  read -r -p "  ${prompt} ${hint} " reply || reply=""
  reply="${reply:-$default}"
  case "$reply" in y|Y|yes|YES|Yes) return 0 ;; *) return 1 ;; esac
}

# ---------- capability checks (idempotency helpers) ----------
have_cmd() { command -v "$1" >/dev/null 2>&1; }

is_wsl() { grep -qiE "microsoft|wsl" /proc/version 2>/dev/null; }

has_gpu() { have_cmd nvidia-smi && nvidia-smi -L >/dev/null 2>&1; }

# free disk space in whole GB for a given path (defaults to $HOME)
free_disk_gb() { df -BG --output=avail "${1:-$HOME}" 2>/dev/null | tail -1 | tr -dc '0-9'; }

# total system memory in whole GB
mem_total_gb() { awk '/MemTotal/ {printf "%d", $2/1024/1024}' /proc/meminfo 2>/dev/null; }

# is a Debian/Ubuntu package installed?
apt_installed() { dpkg -s "$1" >/dev/null 2>&1; }

# is an Ollama model already present locally?
ollama_has_model() { ollama list 2>/dev/null | awk '{print $1}' | grep -qx "$1"; }

# can we reach the internet right now? (used only during setup, never offline)
have_internet() { curl -fsS --max-time 8 https://ollama.com >/dev/null 2>&1; }

# ---------- Ollama process management (for setup + research, NOT offline) ----------
OLLAMA_URL="${OLLAMA_URL:-http://127.0.0.1:11434}"

ollama_is_up() { curl -fsS --max-time 3 "$OLLAMA_URL/api/tags" >/dev/null 2>&1; }

# Make sure a normal (networked) Ollama server is running on the host.
ensure_ollama_running() {
  if ollama_is_up; then ok "Ollama server is running."; return 0; fi
  have_cmd ollama || { err "Ollama is not installed yet. Run scripts/02-install-ollama.sh first."; return 1; }
  info "Starting Ollama server in the background..."
  mkdir -p "$HOME/.ollama"
  nohup ollama serve >"$HOME/.ollama/serve.log" 2>&1 &
  local i
  for i in $(seq 1 30); do ollama_is_up && { ok "Ollama server started."; return 0; }; sleep 1; done
  err "Ollama did not start. See $HOME/.ollama/serve.log"; return 1
}

# ---------- configuration ----------
# Load user config if it exists (written by 05-setup-workspaces.sh).
BASE_DIR_DEFAULT="$HOME/local-agent"
load_config() {
  local cfg="${1:-$BASE_DIR_DEFAULT/config.env}"
  # sensible defaults (overridden by config.env if present)
  : "${BASE_DIR:=$BASE_DIR_DEFAULT}"
  : "${MODEL_FAST:=qwen2.5-coder:7b}"
  : "${MODEL_WORK:=qwen3-coder:30b}"
  : "${MODEL_EMBED:=nomic-embed-text}"
  if [ -f "$cfg" ]; then . "$cfg"; fi
  : "${SECURE_DIR:=$BASE_DIR/secure}"
  : "${RESEARCH_DIR:=$BASE_DIR/research}"
  : "${BRIDGE_DIR:=$BASE_DIR/bridge}"
  export BASE_DIR MODEL_FAST MODEL_WORK MODEL_EMBED SECURE_DIR RESEARCH_DIR BRIDGE_DIR
}

# ---------- the air-gap: run a script file with NO network access ----------
# Picks the best available isolation method and runs the given bash script FILE
# inside a namespace that has no route to the internet (only loopback).
# Usage: run_isolated /path/to/inner_script.sh
run_isolated() {
  local inner="$1"
  [ -f "$inner" ] || { err "internal: isolation payload '$inner' missing"; return 1; }

  # Method 1: Docker with --network none (only if the optional image was built).
  if [ "${ISO_METHOD:-auto}" != "namespace" ] && have_cmd docker \
       && docker image inspect local-agent-offline >/dev/null 2>&1; then
    info "Isolation: Docker (--network none)."
    docker run --rm -i --network none ${GPU_FLAG:-} \
      -v "$HOME/.ollama:/root/.ollama" \
      -v "$SECURE_DIR:/work" -v "$BRIDGE_DIR:/bridge" \
      -v "$inner:/inner.sh:ro" \
      local-agent-offline bash /inner.sh
    return $?
  fi

  # Method 2: unprivileged user+network namespace (NO sudo, NO admin). Preferred.
  if unshare --user --map-root-user --net --fork true >/dev/null 2>&1; then
    info "Isolation: private network namespace (no admin needed)."
    unshare --user --map-root-user --net --fork \
      bash -c 'ip link set lo up 2>/dev/null; exec bash "$0"' "$inner"
    return $?
  fi

  # Method 3: sudo network namespace, dropping back to the real user.
  if have_cmd sudo && have_cmd runuser; then
    warn "Falling back to 'sudo' for network isolation (you may be asked for your password)."
    sudo unshare --net --fork bash -c \
      'ip link set lo up; exec runuser -u '"$USER"' -- bash "$0"' "$inner"
    return $?
  fi

  err "No usable isolation method found."
  err "Fix: run scripts/06-docker-optional.sh, or ask your admin to enable unprivileged user namespaces."
  return 1
}
