#!/usr/bin/env bash
# 04-install-agents.sh - Installs the coding agent(s). Idempotent.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"

step "Coding agent: Aider (recommended default)"
if have_cmd aider; then
  ok "Aider already installed ($(aider --version 2>/dev/null | head -1))."
else
  have_cmd pipx || die "pipx missing. Run scripts/01-install-base.sh first."
  info "Installing Aider (isolated, via pipx)..."
  pipx install aider-chat
  if have_cmd aider; then ok "Aider installed."
  else warn "Aider installed but not on PATH yet. Open a NEW terminal, or run: pipx ensurepath"; fi
fi

step "Optional terminal agent: OpenCode"
if have_cmd opencode; then
  ok "OpenCode already installed."
elif ask_yes_no "Install OpenCode too (optional terminal agent)?" no; then
  if have_cmd npm; then
    npm install -g opencode-ai && ok "OpenCode installed." || warn "OpenCode install failed; skipping (Aider still works)."
  else
    warn "npm (Node.js) not found; skipping OpenCode. Aider is enough to start."
  fi
else
  info "Skipped OpenCode. You can install it later."
fi

info "Note: Cline runs inside VS Code. See USAGE.md for the 2-minute VS Code setup."
