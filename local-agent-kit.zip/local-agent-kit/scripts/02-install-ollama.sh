#!/usr/bin/env bash
# 02-install-ollama.sh - Installs Ollama (the local model runner) if missing, then starts it.
# Idempotent: skips install if Ollama is already present.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"

step "Ollama (local model server)"

if have_cmd ollama; then
  ok "Ollama already installed ($(ollama --version 2>/dev/null | head -1))."
else
  have_internet || die "No internet. Ollama install needs internet once."
  info "Downloading and installing Ollama (official installer)..."
  curl -fsSL https://ollama.com/install.sh | sh
  have_cmd ollama || die "Ollama install did not complete. See https://ollama.com/download"
  ok "Ollama installed."
fi

ensure_ollama_running || die "Could not start Ollama."

if has_gpu; then
  ok "GPU present - Ollama will use it automatically for supported models."
else
  warn "No GPU visible; Ollama will run on CPU (slower)."
fi
info "Test it any time with:  ollama list"
