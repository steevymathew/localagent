#!/usr/bin/env bash
# 06-docker-optional.sh - OPTIONAL. Stronger isolation using Docker (--network none)
# plus filesystem sandboxing. You do NOT need this: the default offline launcher
# already air-gaps the network with no admin. Use this only if you want the extra
# filesystem isolation. Installs Docker Engine INSIDE WSL (no Docker Desktop, no Windows admin).
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"
load_config

step "Optional Docker isolation"
warn "This is advanced and optional. Skip it unless you specifically want Docker."
ask_yes_no "Continue installing/using Docker?" no || { info "Skipped Docker. The default namespace air-gap still works."; exit 0; }

# 1) Docker Engine
if have_cmd docker; then ok "Docker already installed."
else
  have_internet || die "No internet; Docker install needs it once."
  have_cmd sudo || die "sudo needed to install Docker."
  info "Installing Docker Engine inside WSL (official convenience script)..."
  curl -fsSL https://get.docker.com | sudo sh
  sudo usermod -aG docker "$USER" || true
  ok "Docker installed. You may need to open a NEW terminal for group changes."
fi

# 2) Make sure the daemon runs (WSL may not use systemd)
if ! docker info >/dev/null 2>&1; then
  info "Starting Docker daemon..."
  sudo service docker start 2>/dev/null || (sudo dockerd >/tmp/dockerd.log 2>&1 &) || true
  sleep 3
fi
docker info >/dev/null 2>&1 && ok "Docker daemon is running." || warn "Docker daemon not confirmed; see TROUBLESHOOTING.md."

# 3) NVIDIA container toolkit (so the container can use the GPU) - only if a GPU exists
if has_gpu; then
  if docker run --rm --gpus all ubuntu:22.04 nvidia-smi -L >/dev/null 2>&1; then
    ok "Docker can already use the GPU."
  else
    info "Installing NVIDIA Container Toolkit so Docker can use the GPU..."
    if ! apt_installed nvidia-container-toolkit; then
      curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
      curl -fsSL https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
        sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
        sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list >/dev/null
      sudo apt-get update -y && sudo apt-get install -y nvidia-container-toolkit
      sudo nvidia-ctk runtime configure --runtime=docker || true
      sudo service docker restart 2>/dev/null || true
    fi
    docker run --rm --gpus all ubuntu:22.04 nvidia-smi -L >/dev/null 2>&1 \
      && ok "GPU now available in Docker." || warn "GPU-in-Docker not confirmed; the namespace launcher still uses the GPU natively."
  fi
fi

# 4) Build the offline image if missing
if docker image inspect local-agent-offline >/dev/null 2>&1; then
  ok "Offline image 'local-agent-offline' already built."
else
  info "Building the offline agent image (one time)..."
  BUILD="$(mktemp -d)"
  cat > "$BUILD/Dockerfile" <<'DOCKEREOF'
FROM ubuntu:22.04
ENV DEBIAN_FRONTEND=noninteractive
RUN apt-get update && apt-get install -y curl ca-certificates git python3 python3-pip pipx \
    && rm -rf /var/lib/apt/lists/*
RUN curl -fsSL https://ollama.com/install.sh | sh
RUN pipx install aider-chat && pipx ensurepath
ENV PATH="/root/.local/bin:${PATH}"
WORKDIR /work
DOCKEREOF
  docker build -t local-agent-offline "$BUILD" && ok "Image built." || warn "Image build failed; see TROUBLESHOOTING.md."
  rm -rf "$BUILD"
fi
info "Done. The offline launcher will now automatically prefer Docker isolation."
