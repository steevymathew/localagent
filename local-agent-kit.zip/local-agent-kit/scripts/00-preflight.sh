#!/usr/bin/env bash
# 00-preflight.sh - Checks your machine BEFORE anything is installed.
# Changes nothing. Safe to run any time. Tells you what is/ isn't ready.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"
load_config

step "Checking your system (nothing will be installed in this step)"

# Running inside WSL2?
if is_wsl; then ok "Running inside WSL (Linux on Windows)."
else warn "This does not look like WSL. The kit is designed for WSL2 on Windows; it may still work."; fi

# CPU
CORES="$(nproc 2>/dev/null || echo '?')"; ok "CPU threads available: $CORES"

# RAM
RAM="$(mem_total_gb)"; RAM="${RAM:-0}"
if [ "$RAM" -ge 40 ]; then ok "Memory visible to Linux: ${RAM} GB (good)."
elif [ "$RAM" -ge 20 ]; then warn "Memory visible to Linux: ${RAM} GB. For the big model, raise it with the Windows step (Set-WSLConfig)."
else warn "Only ${RAM} GB visible to Linux. Run the Windows step first to give WSL more memory."; fi

# GPU
if has_gpu; then
  NAME="$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1)"
  ok "GPU detected: ${NAME:-NVIDIA}. (Fast local models will use it.)"
else
  warn "No NVIDIA GPU visible to Linux. Models will still run on CPU but much slower."
  warn "Make sure the NVIDIA driver is installed in Windows; the GPU then appears in WSL automatically."
fi

# Disk
DISK="$(free_disk_gb "$HOME")"; DISK="${DISK:-0}"
if [ "$DISK" -ge 60 ]; then ok "Free disk in your Linux home: ${DISK} GB (good)."
elif [ "$DISK" -ge 25 ]; then warn "Free disk: ${DISK} GB. Enough for the small model; the big model needs ~20 GB more."
else warn "Free disk: ${DISK} GB. Free up space before pulling models."; fi

# Internet (needed ONCE, for setup only)
if have_internet; then ok "Internet reachable (needed only during setup)."
else warn "No internet right now. Setup needs internet once to download tools and models."; fi

step "Preflight summary"
info "If you saw mostly [ok], you are ready. Run:  ./setup.sh"
info "Yellow [!] lines are advice, not errors - setup can still proceed."
