#!/usr/bin/env bash
# 01-install-base.sh - Installs the basic Linux tools the kit needs.
# Idempotent: only installs packages that are MISSING.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"

step "Base tools"

PKGS=(curl ca-certificates git jq python3 python3-venv python3-pip pipx iproute2 uidmap util-linux)
MISSING=()
for p in "${PKGS[@]}"; do
  if apt_installed "$p"; then ok "$p already installed."
  else MISSING+=("$p"); fi
done

if [ "${#MISSING[@]}" -eq 0 ]; then
  ok "All base tools already present. Nothing to do."
else
  info "Need to install: ${MISSING[*]}"
  if ! have_cmd sudo; then die "sudo not found. Open Ubuntu as your normal user (you have root inside WSL)."; fi
  info "Updating package lists (you may be asked for your WSL password)..."
  sudo apt-get update -y
  sudo apt-get install -y "${MISSING[@]}"
  ok "Base tools installed."
fi

# make sure pipx-installed tools are on PATH for future shells
if have_cmd pipx; then
  pipx ensurepath >/dev/null 2>&1 || true
  ok "pipx PATH ensured (open a new terminal later if 'aider' is not found)."
fi
