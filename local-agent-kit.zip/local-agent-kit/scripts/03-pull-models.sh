#!/usr/bin/env bash
# 03-pull-models.sh - Downloads the local AI models. Idempotent: skips models you already have.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"
load_config
ensure_ollama_running || die "Ollama must be running to pull models."

pull_if_missing() {
  local model="$1" label="$2"
  if ollama_has_model "$model"; then ok "$label already downloaded ($model)."; return 0; fi
  info "Downloading $label ($model). This can take a while..."
  if ollama pull "$model"; then ok "$label ready."; else
    warn "Could not pull '$model'. The name may have changed."
    warn "Check available tags at https://ollama.com/library and edit the model names in:"
    warn "  $BASE_DIR/config.env  (or scripts/common.sh defaults)"
    return 1
  fi
}

step "Small 'fast' model (fits fully on your GPU)"
pull_if_missing "$MODEL_FAST" "Fast coder" || true

step "Embedding model (for local code search)"
pull_if_missing "$MODEL_EMBED" "Embeddings" || true

step "Big 'workhorse' model (uses your RAM via expert-offload)"
DISK="$(free_disk_gb "$HOME")"; DISK="${DISK:-0}"
if ollama_has_model "$MODEL_WORK"; then
  ok "Workhorse already downloaded ($MODEL_WORK)."
elif [ "$DISK" -lt 25 ]; then
  warn "Only ${DISK} GB free; the workhorse needs ~20 GB. Skipping. Free space and re-run this script."
else
  info "The workhorse ($MODEL_WORK) is ~19 GB and gives you 30B-class quality."
  if ask_yes_no "Download the workhorse model now?" yes; then
    pull_if_missing "$MODEL_WORK" "Workhorse coder" || true
  else
    info "Skipped. Re-run this script later to get it."
  fi
fi

step "Optional: Devstral (strong agentic model, ~14 GB)"
if ollama_has_model "devstral"; then ok "Devstral already present."
elif ask_yes_no "Also download Devstral (optional, extra ~14 GB)?" no; then
  pull_if_missing "devstral" "Devstral" || true
else info "Skipped Devstral (you can add it later with: ollama pull devstral)."; fi

step "Models installed:"
ollama list || true
