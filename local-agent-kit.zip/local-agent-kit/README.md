# Local Agent Kit

A private, **offline** AI coding assistant for your Windows laptop — plus a separate
**research** assistant that is allowed on the internet. They never run at the same time,
and they only share information through one carefully controlled folder.

Built for: MSI Vector 16 (i9‑14900HX, 65 GB RAM, RTX 4060 8 GB) running Windows + WSL2.
**No Windows administrator rights are required.**

---

## What you get

- **The Secure Assistant (offline).** A coding agent that runs with *no internet access at
  all* — enforced by the operating system, not just by a setting. Your source code cannot
  leave the machine. Use this for anything sensitive or proprietary.
- **The Research Assistant (online).** A second agent that *can* use the internet to look up
  documentation and examples. It never sees your secret code.
- **The Bridge.** One folder with two trays (`in` and `out`) for moving notes between the two
  sides, with a simple golden rule that keeps you safe.

Everything runs locally using **Ollama** (the model runner) and **Aider** (the coding agent),
with the **Qwen** family of coding models. All free and open‑source.

---

## Before you start — what you need

- Your laptop with **WSL2** already installed (you said it is). No admin needed.
- About **45–60 minutes**, mostly waiting for downloads.
- About **40 GB free disk space** (the big model is ~19 GB).
- An **internet connection for setup only** — after that the Secure Assistant works offline
  forever.

---

## Quick start (3 steps)

1. **Windows step.** Unzip this folder, open `windows/`, and double‑click
   **`Run-Windows-Setup.bat`**. Say **Yes** to restart WSL. *(Gives Linux enough memory.)*
2. **Install step.** Open **Ubuntu** (search "Ubuntu" in the Start menu), then copy‑paste the
   commands from **`INSTALL.md`** → they end with `./setup.sh`. Answer the friendly prompts.
3. **Use it.** 
   - Prove it's offline: `./bin/verify-airgap.sh` → should say **PASS**.
   - Start coding privately: `./bin/start-offline.sh`
   - Start researching online: `./bin/start-research.sh`

Full details are in **`INSTALL.md`**. Day‑to‑day examples are in **`USAGE.md`**.
Stuck? See **`TROUBLESHOOTING.md`** or run `./bin/doctor.sh`.

---

## What's in the box

```
local-agent-kit/
  README.md              <- you are here
  INSTALL.md             <- step-by-step install (start here after the Windows step)
  USAGE.md               <- how to use it every day, with examples
  TROUBLESHOOTING.md     <- fixes for common problems
  setup.sh               <- the one command that installs everything (safe to re-run)
  windows/
    Run-Windows-Setup.bat  <- double-click this first (Windows side)
    Set-WSLConfig.ps1      <- (what the .bat runs; gives WSL more memory)
  scripts/               <- the individual install steps (run automatically by setup.sh)
    common.sh  00-preflight.sh  01-install-base.sh  02-install-ollama.sh
    03-pull-models.sh  04-install-agents.sh  05-setup-workspaces.sh  06-docker-optional.sh
  bin/                   <- the things you run day to day
    start-offline.sh   start-research.sh   verify-airgap.sh   doctor.sh
```

After setup, your working folders live in **`~/local-agent/`**:
`secure/` (your private code), `research/` (internet‑facing scratch space), and
`bridge/` (the hand‑off trays).

---

## The safety model, in plain words

- The Secure Assistant runs inside a sealed "room" with **no door to the internet**. Even if
  something tried to send your code out, there is physically no network to send it on.
- The Research Assistant has internet, so it is the one exposed to risk — therefore it **never
  gets access to your secret code**. If it can't see the secret, it can't leak the secret.
- Notes crossing the Bridge are **information to read, never commands to obey**. (More on this
  in `USAGE.md` and in `~/local-agent/bridge/README.txt`.)
- Your secure folder is a **git repository**, so every change can be undone.

You can re‑run `./setup.sh` any time; it checks what already exists and only does what's missing.
