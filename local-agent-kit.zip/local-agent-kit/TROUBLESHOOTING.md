# TROUBLESHOOTING

Run `./bin/doctor.sh` first — it points at the exact script to fix most issues.

---

### "aider: command not found" (right after installing)
The tool is installed but your terminal hasn't noticed yet.
```bash
pipx ensurepath
```
Then **close Ubuntu and open it again**. Or run `source ~/.bashrc`.

---

### Scripts fail with `$'\r': command not found` or `bad interpreter`
The files still have Windows line endings. Fix once:
```bash
cd ~/local-agent-kit
find . -name '*.sh' -exec sed -i 's/\r$//' {} +
chmod +x setup.sh scripts/*.sh bin/*.sh
```

---

### "Permission denied" when running a script
```bash
chmod +x setup.sh scripts/*.sh bin/*.sh
```

---

### The GPU isn't being used / everything is very slow
- The NVIDIA driver must be installed **in Windows**, not in WSL. Do **not** install an NVIDIA
  driver inside Ubuntu.
- Check the GPU is visible to Linux:
  ```bash
  nvidia-smi
  ```
  If that shows your RTX 4060, you're good. If not, update the NVIDIA driver in Windows and
  run `wsl --shutdown` (from a normal Windows terminal), then reopen Ubuntu.
- Use the fast model for snappier responses: `./bin/start-offline.sh <folder> qwen2.5-coder:7b`.

---

### The big model is slow or runs out of memory
- Make sure the Windows step ran (Step 1). Confirm Linux sees enough RAM:
  ```bash
  ./bin/doctor.sh    # look at "RAM (GB)"
  ```
  It should be ~48. If it's small, re‑run `windows/Run-Windows-Setup.bat` and restart WSL.
- Long conversations use more memory. Start a fresh session (`/exit` then relaunch) for big
  new tasks.
- If it still won't fit, use the fast 7B model.

---

### `verify-airgap.sh` does not say PASS
Your system may block the no‑admin isolation method. Options:
- Use the Docker method instead: `./scripts/06-docker-optional.sh`, then re‑run
  `./bin/verify-airgap.sh`.
- Ask whoever manages the laptop to enable "unprivileged user namespaces" (a standard Linux
  feature). Until it passes, don't use the secure box for sensitive work.

---

### "Could not pull model" / model name not found
Model names on Ollama occasionally change. See the current names at
https://ollama.com/library , then edit `~/local-agent/config.env` and set `MODEL_WORK` /
`MODEL_FAST` to the correct tag. Re‑run `./scripts/03-pull-models.sh`.

---

### Out of disk space
Models are large. See what you have and remove unused ones:
```bash
ollama list
ollama rm <model-name>
df -h ~     # check free space
```

---

### "No internet" during setup
Setup needs the internet **once** to download tools and models. Connect to Wi‑Fi and run
`./setup.sh` again. (After setup, the Secure Assistant never needs internet.)

---

### Docker (optional path) — daemon not running
```bash
sudo service docker start
docker info        # should print details, not an error
```
If your WSL doesn't use `systemd`, the setup script starts the daemon for you; just re‑run
`./scripts/06-docker-optional.sh`.

---

### Start fresh
The kit never deletes your code. To reset just the tools/models:
```bash
ollama list && ollama rm <models you don't want>
rm -rf ~/local-agent          # removes workspaces + config (NOT your original code copies)
./setup.sh                    # rebuilds everything
```

---

### Still stuck?
Run `./bin/doctor.sh` and read the labels next to any **NO**/**missing** item — each one names
the script that fixes it. Re‑running `./setup.sh` resolves most problems safely.
