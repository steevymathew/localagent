#!/usr/bin/env bash
# common.sh — shared helpers for the Local Agent Kit (AlmaLinux 9 / WSL2).
# SOURCED by the other scripts. Safe to source repeatedly.

if [ -t 1 ]; then
  C_RESET="\033[0m"; C_BOLD="\033[1m"; C_RED="\033[31m"; C_GREEN="\033[32m"
  C_YELLOW="\033[33m"; C_BLUE="\033[36m"
else
  C_RESET=""; C_BOLD=""; C_RED=""; C_GREEN=""; C_YELLOW=""; C_BLUE=""
fi
step()  { printf "\n${C_BOLD}${C_BLUE}==> %s${C_RESET}\n" "$*"; }
ok()    { printf "  ${C_GREEN}[ok]${C_RESET} %s\n" "$*"; }
warn()  { printf "  ${C_YELLOW}[!]${C_RESET} %s\n" "$*"; }
err()   { printf "  ${C_RED}[x]${C_RESET} %s\n" "$*" >&2; }
info()  { printf "  %s\n" "$*"; }
die()   { err "$*"; exit 1; }

ask_yes_no() {
  local prompt="$1" default="${2:-yes}" reply
  if [ ! -t 0 ]; then [ "$default" = "yes" ] && return 0 || return 1; fi
  local hint="[Y/n]"; [ "$default" = "no" ] && hint="[y/N]"
  read -r -p "  ${prompt} ${hint} " reply || reply=""
  reply="${reply:-$default}"
  case "$reply" in y|Y|yes|YES|Yes) return 0 ;; *) return 1 ;; esac
}

# ---------- environment detection ----------
# Is a real PROGRAM installed? "type -P" only finds executable files in PATH, so shell
# builtins/keywords (e.g. "continue", "cd") correctly report as NOT installed.
have_cmd() { [ -n "$(type -P "$1" 2>/dev/null)" ]; }
is_wsl()   { grep -qiE "microsoft|wsl" /proc/version 2>/dev/null; }
is_root()  { [ "$(id -u)" -eq 0 ]; }
has_gpu()  { have_cmd nvidia-smi && nvidia-smi -L >/dev/null 2>&1; }

# AlmaLinux/RHEL family?
is_el() { [ -f /etc/redhat-release ] || grep -qiE 'rhel|almalinux|centos|rocky' /etc/os-release 2>/dev/null; }
el_version() { . /etc/os-release 2>/dev/null; echo "${VERSION_ID%%.*}"; }

free_disk_gb() { df -BG --output=avail "${1:-$HOME}" 2>/dev/null | tail -1 | tr -dc '0-9'; }
mem_total_gb() { awk '/MemTotal/ {printf "%d", $2/1024/1024}' /proc/meminfo 2>/dev/null; }

# rpm-based package check
rpm_installed() { rpm -q "$1" >/dev/null 2>&1; }

# Run a privileged command: use sudo only when not already root.
# AlmaLinux WSL images often log you in AS ROOT, where sudo may not even exist.
SUDO=""
init_sudo() {
  if is_root; then SUDO=""
  elif have_cmd sudo; then SUDO="sudo"
  else die "You are not root and 'sudo' is not installed. Run this as root, or install sudo."; fi
  export SUDO
}

# dnf install only the packages that are actually missing.
dnf_ensure() {
  init_sudo
  local missing=() p
  for p in "$@"; do
    if rpm_installed "$p"; then ok "$p already installed."; else missing+=("$p"); fi
  done
  if [ "${#missing[@]}" -eq 0 ]; then return 0; fi
  info "Installing: ${missing[*]}"
  $SUDO dnf install -y "${missing[@]}" || {
    warn "Batch install failed; trying one at a time so one bad package can't block the rest."
    for p in "${missing[@]}"; do $SUDO dnf install -y "$p" || warn "Could not install $p (continuing)."; done
  }
}

# ---------- Python (critical on AlmaLinux 9) ----------
# EL9 ships Python 3.9, but modern agents need >= 3.10. We locate/install 3.11+.
PYBIN=""
detect_python() {
  local c
  for c in python3.13 python3.12 python3.11 python3.10; do
    if have_cmd "$c"; then PYBIN="$(command -v "$c")"; export PYBIN; return 0; fi
  done
  # is the default python3 already new enough?
  if have_cmd python3 && python3 -c 'import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)' 2>/dev/null; then
    PYBIN="$(command -v python3)"; export PYBIN; return 0
  fi
  return 1
}

# ---------- Ollama ----------
OLLAMA_URL="${OLLAMA_URL:-http://127.0.0.1:11434}"
ollama_is_up() { curl -fsS --max-time 3 "$OLLAMA_URL/api/tags" >/dev/null 2>&1; }
ollama_has_model() { ollama list 2>/dev/null | awk 'NR>1{print $1}' | grep -qx "$1"; }
have_internet() { curl -fsS --max-time 8 https://ollama.com >/dev/null 2>&1; }

ensure_ollama_running() {
  if ollama_is_up; then ok "Ollama server is running."; return 0; fi
  have_cmd ollama || { err "Ollama not installed. Run scripts/03-install-ollama.sh"; return 1; }
  # Prefer systemd if it is actually running (WSL needs systemd=true in /etc/wsl.conf).
  if have_cmd systemctl && systemctl is-system-running >/dev/null 2>&1; then
    init_sudo; $SUDO systemctl enable --now ollama >/dev/null 2>&1 || true
    for i in $(seq 1 20); do ollama_is_up && { ok "Ollama started (systemd)."; return 0; }; sleep 1; done
  fi
  info "Starting Ollama in the background (no systemd needed)..."
  mkdir -p "$HOME/.ollama"
  nohup ollama serve >"$HOME/.ollama/serve.log" 2>&1 &
  for i in $(seq 1 30); do ollama_is_up && { ok "Ollama started."; return 0; }; sleep 1; done
  err "Ollama did not start. Check $HOME/.ollama/serve.log"; return 1
}

# ---------- configuration ----------
BASE_DIR_DEFAULT="$HOME/local-agent"
load_config() {
  : "${BASE_DIR:=$BASE_DIR_DEFAULT}"
  : "${MODEL_FAST:=qwen2.5-coder:7b}"
  : "${MODEL_WORK:=qwen3-coder:30b}"
  : "${MODEL_EMBED:=nomic-embed-text}"
  local cfg="${1:-$BASE_DIR/config.env}"
  [ -f "$cfg" ] && . "$cfg"
  : "${SECURE_DIR:=$BASE_DIR/secure}"
  : "${RESEARCH_DIR:=$BASE_DIR/research}"
  : "${BRIDGE_DIR:=$BASE_DIR/bridge}"
  export BASE_DIR MODEL_FAST MODEL_WORK MODEL_EMBED SECURE_DIR RESEARCH_DIR BRIDGE_DIR
}

# ---------- the air-gap ----------
# Run a bash script FILE with NO route to the internet.
run_isolated() {
  local inner="$1"
  [ -f "$inner" ] || { err "internal: payload '$inner' missing"; return 1; }

  # Method 1: unprivileged user+network namespace. No admin, no Docker. Preferred.
  if [ "${ISO_METHOD:-auto}" != "sudo" ] && unshare --user --map-root-user --net --fork true >/dev/null 2>&1; then
    info "Isolation: private network namespace (no admin needed)."
    unshare --user --map-root-user --net --fork \
      bash -c 'ip link set lo up 2>/dev/null || true; exec bash "$0"' "$inner"
    return $?
  fi

  # Method 2: plain root/sudo network namespace (we are often root in WSL anyway).
  if is_root; then
    info "Isolation: network namespace (running as root)."
    unshare --net --fork bash -c 'ip link set lo up 2>/dev/null || true; exec bash "$0"' "$inner"
    return $?
  fi
  if have_cmd sudo; then
    warn "Using sudo for network isolation (you may be asked for your password)."
    if have_cmd runuser; then
      sudo unshare --net --fork bash -c \
        'ip link set lo up 2>/dev/null || true; exec runuser -u '"$USER"' -- bash "$0"' "$inner"
    else
      sudo unshare --net --fork bash -c 'ip link set lo up 2>/dev/null || true; exec bash "$0"' "$inner"
    fi
    return $?
  fi

  err "No usable isolation method found."
  err "Fix: run  scripts/08-enable-userns.sh   (see TROUBLESHOOTING in the instructions)."
  return 1
}
