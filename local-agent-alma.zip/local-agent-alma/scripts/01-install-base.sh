#!/usr/bin/env bash
# 01-install-base.sh — Base tools via dnf. Only installs what is missing.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"
init_sudo

step "Base tools (AlmaLinux / dnf)"

# CAVEAT: do NOT 'dnf install curl' on EL9 — it collides with the preinstalled
# curl-minimal package. Only install if the command is genuinely absent.
if have_cmd curl; then ok "curl already available (not touching curl-minimal)."
else dnf_ensure curl; fi

# util-linux gives us 'unshare' (the air-gap); iproute gives 'ip'.
dnf_ensure git tar gzip which jq iproute util-linux shadow-utils procps-ng ca-certificates

# EPEL provides pipx and other extras. Harmless if already enabled.
if rpm_installed epel-release; then ok "EPEL already enabled."
else
  info "Enabling EPEL (extra package repository)..."
  $SUDO dnf install -y epel-release || warn "Could not enable EPEL; setup will fall back to pip."
fi

ok "Base tools done."
