#!/usr/bin/env bash
# 02-install-python.sh — THE ALMALINUX 9 GOTCHA.
# AlmaLinux 9's default Python is 3.9. Agents like Aider need 3.10+.
# We install Python 3.11 ALONGSIDE it (the system 3.9 is untouched — dnf needs it).
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"
init_sudo

step "Modern Python (3.11) for the agent"

if detect_python; then
  ok "Usable Python already present: $PYBIN ($("$PYBIN" -V 2>&1))"
else
  info "Installing python3.11 (leaves the system's 3.9 alone — do NOT remove that)."
  dnf_ensure python3.11 python3.11-pip
  detect_python || die "Python 3.11 install failed. Try: $SUDO dnf install -y python3.12 python3.12-pip"
  ok "Installed: $PYBIN ($("$PYBIN" -V 2>&1))"
fi

step "pipx (installs agent tools in their own clean sandbox)"
if have_cmd pipx; then
  ok "pipx already installed."
else
  if $SUDO dnf install -y pipx 2>/dev/null && have_cmd pipx; then
    ok "pipx installed from EPEL."
  else
    info "EPEL pipx unavailable; installing pipx via pip for your user instead."
    "$PYBIN" -m pip install --user --upgrade pip >/dev/null 2>&1 || true
    "$PYBIN" -m pip install --user pipx || die "Could not install pipx."
    export PATH="$HOME/.local/bin:$PATH"
  fi
fi

# Make ~/.local/bin permanent so 'aider' is found in future terminals.
have_cmd pipx && pipx ensurepath >/dev/null 2>&1 || true
if ! grep -q 'HOME/.local/bin' "$HOME/.bashrc" 2>/dev/null; then
  echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
  ok "Added ~/.local/bin to your PATH (takes effect in new terminals)."
else
  ok "PATH already configured."
fi
