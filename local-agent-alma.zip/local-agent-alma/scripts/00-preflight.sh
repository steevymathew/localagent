#!/usr/bin/env bash
# 00-preflight.sh — Look at the machine. Install NOTHING. Safe any time.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"; load_config

step "System check (nothing is installed in this step)"

if is_wsl; then ok "Running inside WSL."; else warn "Not WSL — kit is designed for WSL2, may still work."; fi

if is_el; then
  . /etc/os-release 2>/dev/null || true
  ok "Linux: ${PRETTY_NAME:-RHEL-family} (dnf-based — correct for this kit)."
  [ "$(el_version)" = "9" ] || warn "Expected version 9; found $(el_version). Should still work."
else
  warn "This does not look like AlmaLinux/RHEL. This kit uses 'dnf'. On Ubuntu/Debian it will not work."
fi

is_root && warn "You are logged in as ROOT. That works, but a normal user is safer (instructions Step 3)." \
        || ok "Running as normal user: $USER"

ok "CPU threads: $(nproc 2>/dev/null || echo '?')"

RAM="$(mem_total_gb)"; RAM="${RAM:-0}"
if   [ "$RAM" -ge 40 ]; then ok "RAM visible to Linux: ${RAM} GB (good for the big model)."
elif [ "$RAM" -ge 20 ]; then warn "RAM visible to Linux: ${RAM} GB. Raise it: ./scripts/07-wsl-tuning.sh"
else warn "Only ${RAM} GB visible to Linux. Run ./scripts/07-wsl-tuning.sh then restart WSL."; fi

if has_gpu; then ok "GPU: $(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1)"
else
  warn "No NVIDIA GPU visible. Models run on CPU (much slower)."
  warn "Install/update the NVIDIA driver in WINDOWS (never inside WSL), then run: wsl --shutdown"
fi

if detect_python; then ok "Modern Python found: $PYBIN ($("$PYBIN" -V 2>&1))"
else warn "Python 3.10+ not found. AlmaLinux 9 ships 3.9, which is too old — setup will install 3.11."; fi

DISK="$(free_disk_gb "$HOME")"; DISK="${DISK:-0}"
if   [ "$DISK" -ge 60 ]; then ok "Free disk: ${DISK} GB (good)."
elif [ "$DISK" -ge 25 ]; then warn "Free disk: ${DISK} GB — enough for the small model only."
else warn "Free disk: ${DISK} GB — free up space before downloading models."; fi

if unshare --user --map-root-user --net --fork true >/dev/null 2>&1; then
  ok "Offline isolation available (no admin needed)."
elif is_root; then ok "Offline isolation available (running as root)."
else warn "Isolation test failed; ./scripts/08-enable-userns.sh can fix it."; fi

have_internet && ok "Internet reachable (needed for setup only)." \
              || warn "No internet. Setup needs it once to download tools + models."

step "Summary"
info "Mostly [ok]? Run:  ./setup.sh"
info "Yellow [!] lines are advice, not failures."
