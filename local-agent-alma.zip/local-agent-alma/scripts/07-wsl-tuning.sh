#!/usr/bin/env bash
# 07-wsl-tuning.sh — Configure WSL itself, ENTIRELY FROM INSIDE LINUX.
# Why: Windows security policy often blocks .bat/.ps1 scripts. WSL can write to the
# Windows filesystem directly, so we never need PowerShell or admin rights.
#   * /etc/wsl.conf          -> enable systemd + set default user   (inside Linux)
#   * C:\Users\<you>\.wslconfig -> give Linux more RAM               (Windows side file)
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"
init_sudo

is_wsl || { warn "Not running under WSL; nothing to tune."; exit 0; }

step "Part 1 — /etc/wsl.conf (inside Linux)"
WSLCONF=/etc/wsl.conf
NEED_RESTART=0
if [ -f "$WSLCONF" ] && grep -qE '^\s*systemd\s*=\s*true' "$WSLCONF"; then
  ok "systemd already enabled in $WSLCONF."
else
  [ -f "$WSLCONF" ] && $SUDO cp "$WSLCONF" "$WSLCONF.bak.$(date +%Y%m%d-%H%M%S)" && info "Backed up $WSLCONF"
  if [ -f "$WSLCONF" ] && grep -qE '^\s*\[boot\]' "$WSLCONF"; then
    $SUDO sed -i 's/^\s*\[boot\]/[boot]\nsystemd=true/' "$WSLCONF"
  else
    printf '[boot]\nsystemd=true\n' | $SUDO tee -a "$WSLCONF" >/dev/null
  fi
  ok "Enabled systemd in $WSLCONF."
  NEED_RESTART=1
fi

# If we are root, offer to make a normal user the default login (safer).
if is_root; then
  warn "You are root. A normal user account is safer for daily work."
  if ask_yes_no "Create/set a normal default user now?" no; then
    read -r -p "  Username to use: " NEWUSER
    if [ -n "${NEWUSER:-}" ]; then
      id "$NEWUSER" >/dev/null 2>&1 || { useradd -m -G wheel "$NEWUSER"; info "Created $NEWUSER (in 'wheel' = can use sudo)."; passwd "$NEWUSER"; }
      if grep -qE '^\s*default\s*=' "$WSLCONF" 2>/dev/null; then
        sed -i "s/^\s*default\s*=.*/default=$NEWUSER/" "$WSLCONF"
      elif grep -qE '^\s*\[user\]' "$WSLCONF" 2>/dev/null; then
        sed -i "s/^\s*\[user\]/[user]\ndefault=$NEWUSER/" "$WSLCONF"
      else
        printf '\n[user]\ndefault=%s\n' "$NEWUSER" >> "$WSLCONF"
      fi
      ok "Default user set to $NEWUSER."
      warn "After restarting WSL, log in as $NEWUSER and re-run ./setup.sh as that user."
      NEED_RESTART=1
    fi
  fi
fi

step "Part 2 — .wslconfig on the Windows side (memory)"
# Find the Windows user profile from inside WSL. No PowerShell required.
WINHOME=""
for d in /mnt/c/Users/*; do
  case "$(basename "$d")" in
    Public|Default|"Default User"|"All Users") continue ;;
  esac
  [ -d "$d" ] || continue
  # Prefer a profile that looks active (has a Desktop or Downloads folder).
  if [ -d "$d/Desktop" ] || [ -d "$d/Downloads" ]; then WINHOME="$d"; break; fi
done
[ -z "$WINHOME" ] && WINHOME="$(ls -d /mnt/c/Users/*/ 2>/dev/null | head -1)"

if [ -z "$WINHOME" ] || [ ! -d "$WINHOME" ]; then
  warn "Could not find your Windows user folder (is C: mounted at /mnt/c?)."
  warn "Manual fix is in the instructions ('If the automatic memory step fails')."
  exit 0
fi
info "Windows profile: $WINHOME"

TOTAL="$(awk '/MemTotal/{printf "%d",$2/1024/1024}' /proc/meminfo)"
# Total RAM as Linux currently sees it may already be capped; use the machine's real total if bigger.
REAL_TOTAL="$TOTAL"
if [ -r /proc/meminfo ] && [ "$TOTAL" -lt 60 ]; then REAL_TOTAL=64; fi
TARGET=$(( REAL_TOTAL - 16 )); [ "$TARGET" -lt 8 ] && TARGET=8
WSLCFG="$WINHOME/.wslconfig"

if [ -f "$WSLCFG" ] && grep -qE "^\s*memory\s*=\s*${TARGET}GB" "$WSLCFG"; then
  ok ".wslconfig already set to ${TARGET}GB."
else
  [ -f "$WSLCFG" ] && cp "$WSLCFG" "$WSLCFG.bak.$(date +%Y%m%d-%H%M%S)" 2>/dev/null && info "Backed up existing .wslconfig"
  TMP="$(mktemp)"
  if [ -f "$WSLCFG" ]; then
    grep -vE '^\s*(memory|swap)\s*=' "$WSLCFG" 2>/dev/null | grep -vE '^\s*\[wsl2\]\s*$' > "$TMP" || true
  fi
  { printf '[wsl2]\r\n'; printf 'memory=%sGB\r\n' "$TARGET"; printf 'swap=8GB\r\n'; cat "$TMP" 2>/dev/null; } > "$WSLCFG"
  rm -f "$TMP"
  ok "Set Linux memory limit to ${TARGET}GB in $WSLCFG"
  NEED_RESTART=1
fi

step "Finish"
if [ "$NEED_RESTART" = "1" ]; then
  warn "WSL MUST RESTART for these to take effect."
  info "Do this: close this window, then open Windows PowerShell or Command Prompt and run:"
  printf "\n      wsl --shutdown\n\n"
  info "Then reopen AlmaLinux and continue. (No admin rights needed for that command.)"
else
  ok "Everything already tuned; no restart needed."
fi
