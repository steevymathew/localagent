#!/usr/bin/env bash
# 03-install-ollama.sh — Install the local model runner, then start it.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"

step "Ollama (runs the AI models locally)"

if have_cmd ollama; then
  ok "Ollama already installed ($(ollama --version 2>/dev/null | head -1))."
else
  have_internet || die "No internet — Ollama needs to download once."
  info "Installing Ollama (official installer; works on AlmaLinux)..."
  curl -fsSL https://ollama.com/install.sh | sh
  have_cmd ollama || die "Install failed. Manual steps: https://ollama.com/download/linux"
  ok "Ollama installed."
fi

# On WSL without systemd the installer prints a warning — that is expected and fine.
ensure_ollama_running || die "Ollama could not start. See $HOME/.ollama/serve.log"

if has_gpu; then ok "GPU detected — Ollama will use it automatically."
else warn "No GPU visible; running on CPU (slower). See the instructions' GPU section."; fi
