#!/usr/bin/env bash
# 08-enable-userns.sh — Only needed if ./bin/verify-airgap.sh does NOT say PASS.
# Enables unprivileged user namespaces, which the offline air-gap uses.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"
init_sudo

step "Enable unprivileged user namespaces"

if unshare --user --map-root-user --net --fork true >/dev/null 2>&1; then
  ok "Already working — you do not need this script."; exit 0
fi

CUR="$(cat /proc/sys/user/max_user_namespaces 2>/dev/null || echo 0)"
info "Current user.max_user_namespaces = $CUR"
if [ "$CUR" = "0" ]; then
  info "Enabling now (takes effect immediately)..."
  echo 15000 | $SUDO tee /proc/sys/user/max_user_namespaces >/dev/null || true
  # Persist across restarts.
  echo 'user.max_user_namespaces=15000' | $SUDO tee /etc/sysctl.d/99-userns.conf >/dev/null
  $SUDO sysctl --system >/dev/null 2>&1 || true
  ok "Enabled and made permanent (/etc/sysctl.d/99-userns.conf)."
fi

if unshare --user --map-root-user --net --fork true >/dev/null 2>&1; then
  ok "Success — unprivileged isolation now works."
elif is_root; then
  ok "Not available, BUT you are root, so the air-gap still works (root namespace method)."
else
  warn "Still unavailable. The air-gap will use 'sudo' instead — that works too."
  info "Confirm with: ./bin/verify-airgap.sh"
fi
