#!/usr/bin/env bash
# 05-install-agent.sh — Install Aider, the default coding agent.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"
export PATH="$HOME/.local/bin:$PATH"

step "Aider (the coding agent)"

if have_cmd aider; then
  ok "Aider already installed ($(aider --version 2>/dev/null | head -1))."
else
  detect_python || die "Python 3.10+ missing. Run scripts/02-install-python.sh first."
  if have_cmd pipx; then
    info "Installing Aider with pipx using $PYBIN ..."
    pipx install --python "$PYBIN" aider-chat || pipx install aider-chat
  else
    info "pipx unavailable; installing Aider with pip --user ..."
    "$PYBIN" -m pip install --user aider-chat
  fi
  if have_cmd aider; then ok "Aider installed."
  else warn "Installed, but not on PATH yet — open a NEW terminal (or: source ~/.bashrc)."; fi
fi

info "Want extra agents (OpenCode, Goose, Cline, Continue)? Run: ./bin/add-agent.sh"
