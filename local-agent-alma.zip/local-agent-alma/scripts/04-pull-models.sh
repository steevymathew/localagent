#!/usr/bin/env bash
# 04-pull-models.sh — Download the AI models. Skips any you already have.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/common.sh"; load_config
ensure_ollama_running || die "Ollama must be running first."

pull_if_missing() {
  local model="$1" label="$2"
  if ollama_has_model "$model"; then ok "$label already downloaded ($model)."; return 0; fi
  info "Downloading $label ($model)... this is the slow part; leave it running."
  if ollama pull "$model"; then ok "$label ready."; else
    warn "Could not pull '$model' — the name/tag may have changed."
    warn "Look up the current tag at https://ollama.com/library then edit:"
    warn "  $BASE_DIR/config.env"
    return 1
  fi
}

step "1/3 Fast model (fits entirely on the 8 GB GPU)"
pull_if_missing "$MODEL_FAST" "Fast coder" || true

step "2/3 Embedding model (local code search; tiny)"
pull_if_missing "$MODEL_EMBED" "Embeddings" || true

step "3/3 Workhorse model (30B-class; uses your big RAM)"
DISK="$(free_disk_gb "$HOME")"; DISK="${DISK:-0}"
if ollama_has_model "$MODEL_WORK"; then ok "Workhorse already downloaded ($MODEL_WORK)."
elif [ "$DISK" -lt 25 ]; then warn "Only ${DISK} GB free; needs ~20 GB. Skipped — free space and re-run."
else
  info "This is ~19 GB and gives the best quality on your hardware."
  if ask_yes_no "Download the workhorse model now?" yes; then pull_if_missing "$MODEL_WORK" "Workhorse" || true
  else info "Skipped. Re-run this script any time to get it."; fi
fi

step "Installed models"
ollama list || true
