#!/usr/bin/env bash
# setup.sh — One command to set everything up on AlmaLinux 9 (WSL2).
# Safe to run repeatedly: it skips anything already done.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; . "$HERE/scripts/common.sh"
export PATH="$HOME/.local/bin:$PATH"

printf "\n${C_BOLD}Local Agent Kit — AlmaLinux 9 / WSL2${C_RESET}\n"
printf "Installs a private OFFLINE coding assistant plus a separate ONLINE research one.\n"
printf "Only missing pieces are installed. Ctrl-C is safe — just re-run this later.\n"

bash "$HERE/scripts/00-preflight.sh" || true
ask_yes_no "Proceed with installation?" yes || { info "Stopped. Run ./setup.sh whenever ready."; exit 0; }

bash "$HERE/scripts/01-install-base.sh"
bash "$HERE/scripts/02-install-python.sh"
bash "$HERE/scripts/03-install-ollama.sh"
bash "$HERE/scripts/04-pull-models.sh"
bash "$HERE/scripts/05-install-agent.sh"
bash "$HERE/scripts/06-setup-workspaces.sh"

step "Checking the offline protection"
bash "$HERE/bin/verify-airgap.sh" || {
  warn "Air-gap not confirmed yet — attempting the automatic fix..."
  bash "$HERE/scripts/08-enable-userns.sh" || true
  bash "$HERE/bin/verify-airgap.sh" || warn "Still not confirmed. See the instructions' troubleshooting section."
}

step "Setup complete"
ok "Health check ............ ./bin/doctor.sh"
ok "Prove it's offline ...... ./bin/verify-airgap.sh"
ok "PRIVATE coding .......... ./bin/start-offline.sh"
ok "ONLINE research ......... ./bin/start-research.sh"
ok "Add more agents/models .. ./bin/add-agent.sh"
echo
info "Optional but recommended: give Linux more memory + enable systemd:"
info "    ./scripts/07-wsl-tuning.sh     (then: wsl --shutdown  from Windows)"
info "Next: read SETUP-LOCAL-AGENT-INSTRUCTIONS.md"
